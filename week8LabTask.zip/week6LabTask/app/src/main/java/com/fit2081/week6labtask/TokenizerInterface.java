package com.fit2081.week6labtask;

public interface TokenizerInterface {

    public void sendData(String data);

}
